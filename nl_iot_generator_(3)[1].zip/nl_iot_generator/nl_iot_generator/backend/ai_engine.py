from nlp_parser import parse_command
from dynamic_code_generator import generate_code

def process_command(command):
    intent = parse_command(command)
    result = generate_code(intent)
    return result
