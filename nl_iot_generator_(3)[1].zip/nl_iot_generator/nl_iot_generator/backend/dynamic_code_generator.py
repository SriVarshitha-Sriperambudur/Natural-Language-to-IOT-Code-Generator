def generate_code(intent):
    domain = intent.get("domain")

    if domain is None:
        return None

    operator = intent.get("operator")
    threshold = intent.get("threshold")
    sensor = intent.get("sensor")
    actuator = intent.get("actuator")

    # ---------------- WEATHER / ENVIRONMENT DOMAIN ----------------
    if domain == "weather":
        if sensor == "humidity":
            if threshold is None:
                threshold = 70
            if operator is None:
                operator = ">"
            code = f'''
#include "DHT.h"
#define DHTPIN 4
#define DHTTYPE DHT11
#define ACTUATOR_PIN 2

DHT dht(DHTPIN, DHTTYPE);

void setup() {{
  Serial.begin(115200);
  dht.begin();
  pinMode(ACTUATOR_PIN, OUTPUT);
}}

void loop() {{
  float hum = dht.readHumidity();

  if (isnan(hum)) return;

  if (hum {operator} {threshold}) {{
    digitalWrite(ACTUATOR_PIN, HIGH);
  }} else {{
    digitalWrite(ACTUATOR_PIN, LOW);
  }}

  delay(2000);
}}
'''
            wiring = {
                "DHT11 Sensor": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "DATA": "GPIO 4"
                },
                "Relay/LED": {
                    "IN": "GPIO 2",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "DHT11 Sensor",
                "Relay Module or LED",
                "220 ohm Resistor (if LED)",
                "Breadboard",
                "Jumper Wires"
            ]
        else:
            if threshold is None:
                threshold = 30
            if operator is None:
                operator = ">"
            code = f'''
#include "DHT.h"
#define DHTPIN 4
#define DHTTYPE DHT11
#define ACTUATOR_PIN 2

DHT dht(DHTPIN, DHTTYPE);

void setup() {{
  Serial.begin(115200);
  dht.begin();
  pinMode(ACTUATOR_PIN, OUTPUT);
}}

void loop() {{
  float temp = dht.readTemperature();

  if (isnan(temp)) return;

  if (temp {operator} {threshold}) {{
    digitalWrite(ACTUATOR_PIN, HIGH);
  }} else {{
    digitalWrite(ACTUATOR_PIN, LOW);
  }}

  delay(2000);
}}
'''
            wiring = {
                "DHT11 Sensor": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "DATA": "GPIO 4"
                },
                "Relay/LED": {
                    "IN": "GPIO 2",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "DHT11 Sensor",
                "Relay Module or LED",
                "220 ohm Resistor (if LED)",
                "Breadboard",
                "Jumper Wires"
            ]

    # ---------------- AGRICULTURE DOMAIN ----------------
    elif domain == "agriculture":
        if sensor == "temperature":
            if threshold is None:
                threshold = 35
            if operator is None:
                operator = ">"
            code = f'''
#include "DHT.h"
#define DHTPIN 4
#define DHTTYPE DHT11
#define FAN_PIN 5

DHT dht(DHTPIN, DHTTYPE);

void setup() {{
  Serial.begin(115200);
  dht.begin();
  pinMode(FAN_PIN, OUTPUT);
}}

void loop() {{
  float temp = dht.readTemperature();

  if (isnan(temp)) return;

  if (temp {operator} {threshold}) {{
    digitalWrite(FAN_PIN, HIGH);
  }} else {{
    digitalWrite(FAN_PIN, LOW);
  }}

  delay(2000);
}}
'''
            wiring = {
                "DHT11 Sensor": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "DATA": "GPIO 4"
                },
                "Relay Module (Fan)": {
                    "IN": "GPIO 5",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "DHT11 Sensor",
                "Relay Module",
                "Fan",
                "Breadboard",
                "Jumper Wires"
            ]
        else:
            if threshold is None:
                threshold = 2000
            if operator is None:
                operator = "<"
            code = f'''
#define SOIL_PIN 34
#define PUMP_PIN 5

void setup() {{
  Serial.begin(115200);
  pinMode(PUMP_PIN, OUTPUT);
}}

void loop() {{
  int moisture = analogRead(SOIL_PIN);

  if (moisture {operator} {threshold}) {{
    digitalWrite(PUMP_PIN, HIGH);
  }} else {{
    digitalWrite(PUMP_PIN, LOW);
  }}

  delay(2000);
}}
'''
            wiring = {
                "Soil Moisture Sensor": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "AO": "GPIO 34"
                },
                "Relay Module (Pump)": {
                    "IN": "GPIO 5",
                    "VCC": "5V",
                    "GND": "GND",
                    "COM/NO": "Pump external supply"
                }
            }
            components = [
                "ESP32 Dev Module",
                "Soil Moisture Sensor",
                "Relay Module",
                "Water Pump",
                "Breadboard",
                "Jumper Wires"
            ]

    # ---------------- SMART HOME DOMAIN ----------------
    elif domain == "smart_home":
        if sensor == "motion":
            if threshold is None:
                threshold = 1
            if operator is None:
                operator = ">"
            code = f'''
#define PIR_PIN 27
#define LIGHT_PIN 2

void setup() {{
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  pinMode(LIGHT_PIN, OUTPUT);
}}

void loop() {{
  int motion = digitalRead(PIR_PIN);

  if (motion {operator} {threshold}) {{
    digitalWrite(LIGHT_PIN, HIGH);
  }} else {{
    digitalWrite(LIGHT_PIN, LOW);
  }}

  delay(500);
}}
'''
            wiring = {
                "PIR Sensor": {
                    "VCC": "5V",
                    "GND": "GND",
                    "OUT": "GPIO 27"
                },
                "Relay/LED": {
                    "IN": "GPIO 2",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "PIR Sensor",
                "Relay Module or LED",
                "220 ohm Resistor (if LED)",
                "Breadboard",
                "Jumper Wires"
            ]
        elif sensor == "temperature":
            if threshold is None:
                threshold = 28
            if operator is None:
                operator = ">"
            code = f'''
#include "DHT.h"
#define DHTPIN 4
#define DHTTYPE DHT11
#define FAN_PIN 5

DHT dht(DHTPIN, DHTTYPE);

void setup() {{
  Serial.begin(115200);
  dht.begin();
  pinMode(FAN_PIN, OUTPUT);
}}

void loop() {{
  float temp = dht.readTemperature();

  if (isnan(temp)) return;

  if (temp {operator} {threshold}) {{
    digitalWrite(FAN_PIN, HIGH);
  }} else {{
    digitalWrite(FAN_PIN, LOW);
  }}

  delay(2000);
}}
'''
            wiring = {
                "DHT11 Sensor": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "DATA": "GPIO 4"
                },
                "Relay Module (Fan)": {
                    "IN": "GPIO 5",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "DHT11 Sensor",
                "Relay Module",
                "Fan",
                "Breadboard",
                "Jumper Wires"
            ]
        else:
            if threshold is None:
                threshold = 1800
            if operator is None:
                operator = "<"
            code = f'''
#define LDR_PIN 34
#define LIGHT_PIN 2

void setup() {{
  Serial.begin(115200);
  pinMode(LIGHT_PIN, OUTPUT);
}}

void loop() {{
  int lightValue = analogRead(LDR_PIN);

  if (lightValue {operator} {threshold}) {{
    digitalWrite(LIGHT_PIN, HIGH);
  }} else {{
    digitalWrite(LIGHT_PIN, LOW);
  }}

  delay(1000);
}}
'''
            wiring = {
                "LDR (with 10k resistor divider)": {
                    "One end": "3.3V",
                    "Other end": "GND",
                    "Middle to GPIO": "GPIO 34"
                },
                "Relay/LED": {
                    "IN": "GPIO 2",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "LDR",
                "10k Resistor",
                "Relay Module or LED",
                "Breadboard",
                "Jumper Wires"
            ]

    # ---------------- INDUSTRIAL SAFETY DOMAIN ----------------
    elif domain == "industrial_safety":
        if actuator == "fan":
            if threshold is None:
                threshold = 450
            if operator is None:
                operator = ">"
            code = f'''
#define GAS_PIN 34
#define FAN_PIN 5

void setup() {{
  Serial.begin(115200);
  pinMode(FAN_PIN, OUTPUT);
}}

void loop() {{
  int gas = analogRead(GAS_PIN);

  if (gas {operator} {threshold}) {{
    digitalWrite(FAN_PIN, HIGH);
  }} else {{
    digitalWrite(FAN_PIN, LOW);
  }}

  delay(1000);
}}
'''
            wiring = {
                "MQ-2 Gas Sensor (AO)": {
                    "VCC": "5V",
                    "GND": "GND",
                    "AO": "GPIO 34"
                },
                "Relay Module (Exhaust Fan)": {
                    "IN": "GPIO 5",
                    "VCC": "5V",
                    "GND": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "MQ-2 Gas Sensor",
                "Relay Module",
                "Exhaust Fan",
                "Breadboard",
                "Jumper Wires"
            ]
        else:
            if threshold is None:
                threshold = 400
            if operator is None:
                operator = ">"
            code = f'''
#define GAS_PIN 34
#define BUZZER_PIN 13

void setup() {{
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
}}

void loop() {{
  int gas = analogRead(GAS_PIN);

  if (gas {operator} {threshold}) {{
    digitalWrite(BUZZER_PIN, HIGH);
  }} else {{
    digitalWrite(BUZZER_PIN, LOW);
  }}

  delay(1000);
}}
'''
            wiring = {
                "MQ-2 Gas Sensor (AO)": {
                    "VCC": "5V",
                    "GND": "GND",
                    "AO": "GPIO 34"
                },
                "Buzzer": {
                    "+": "GPIO 13",
                    "-": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "MQ-2 Gas Sensor",
                "Buzzer",
                "Breadboard",
                "Jumper Wires"
            ]

    # ---------------- HEALTHCARE / PATIENT MONITORING DOMAIN ----------------
    elif domain == "healthcare":
        if sensor == "temperature":
            if threshold is None:
                threshold = 38
            if operator is None:
                operator = ">"
            code = f'''
#define TEMP_PIN 34
#define ALERT_PIN 13

void setup() {{
  Serial.begin(115200);
  pinMode(ALERT_PIN, OUTPUT);
}}

void loop() {{
  int raw = analogRead(TEMP_PIN);
  float voltage = raw * (3.3 / 4095.0);
  float tempC = (voltage - 0.5) * 100.0;

  if (tempC {operator} {threshold}) {{
    digitalWrite(ALERT_PIN, HIGH);
  }} else {{
    digitalWrite(ALERT_PIN, LOW);
  }}

  delay(1000);
}}
'''
            wiring = {
                "LM35/Analog Temp Sensor": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "OUT": "GPIO 34"
                },
                "Buzzer/LED": {
                    "+": "GPIO 13",
                    "-": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "LM35 or Analog Temp Sensor",
                "Buzzer or LED",
                "Breadboard",
                "Jumper Wires"
            ]
        else:
            if threshold is None:
                threshold = 110
            if operator is None:
                operator = ">"
            code = f'''
#define PULSE_PIN 34
#define ALERT_PIN 13

void setup() {{
  Serial.begin(115200);
  pinMode(ALERT_PIN, OUTPUT);
}}

void loop() {{
  int pulse = analogRead(PULSE_PIN);

  if (pulse {operator} {threshold}) {{
    digitalWrite(ALERT_PIN, HIGH);
  }} else {{
    digitalWrite(ALERT_PIN, LOW);
  }}

  delay(1000);
}}
'''
            wiring = {
                "Pulse Sensor (Signal)": {
                    "VCC": "3.3V",
                    "GND": "GND",
                    "Signal": "GPIO 34"
                },
                "Buzzer/LED": {
                    "+": "GPIO 13",
                    "-": "GND"
                }
            }
            components = [
                "ESP32 Dev Module",
                "Pulse Sensor",
                "Buzzer or LED",
                "Breadboard",
                "Jumper Wires"
            ]

    else:
        return None

    return {
        "domain": domain,
        "generated_file": f"{domain}_generated.ino",
        "components_required": components,
        "wiring_instructions": wiring,
        "execution_steps": [
            "Copy generated code into Arduino IDE",
            "Select ESP32 Dev Module and COM port",
            "Connect components as per wiring",
            "Upload code to ESP32",
            "Observe actuator response"
        ],
        "code": code
    }
