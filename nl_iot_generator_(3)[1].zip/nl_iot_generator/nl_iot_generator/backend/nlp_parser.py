import re

def parse_command(command):
    text = command.lower()

    intent = {
        "domain": None,
        "sensor": None,
        "actuator": None,
        "operator": None,
        "threshold": None,
        "action": None
    }

    # DOMAIN
    if any(word in text for word in ["soil", "moisture", "pump", "irrigation", "agriculture", "farm", "crop", "field"]):
        intent["domain"] = "agriculture"
    elif any(word in text for word in ["weather", "environment", "temperature", "temp", "humidity"]):
        intent["domain"] = "weather"
    elif any(word in text for word in ["home", "smart home", "automation", "living room", "bedroom", "room", "light", "lamp", "dark", "bright", "pir", "motion"]):
        intent["domain"] = "smart_home"
    elif any(word in text for word in ["industrial", "factory", "safety", "gas", "smoke", "leak"]):
        intent["domain"] = "industrial_safety"
    elif any(word in text for word in ["health", "healthcare", "patient", "heart", "pulse", "spo2", "body", "fever"]):
        intent["domain"] = "healthcare"

    # SENSOR
    if "temp" in text or "temperature" in text:
        intent["sensor"] = "temperature"
    elif "humidity" in text:
        intent["sensor"] = "humidity"
    elif "soil" in text or "moisture" in text:
        intent["sensor"] = "soil"
    elif "light" in text or "ldr" in text or "dark" in text or "bright" in text:
        intent["sensor"] = "light"
    elif "motion" in text or "pir" in text:
        intent["sensor"] = "motion"
    elif "gas" in text or "smoke" in text:
        intent["sensor"] = "gas"
    elif "spo2" in text or "oxygen" in text:
        intent["sensor"] = "spo2"
    elif "pulse" in text or "heart" in text:
        intent["sensor"] = "pulse"

    # ACTUATOR
    if "fan" in text:
        intent["actuator"] = "fan"
    elif "pump" in text or "motor" in text:
        intent["actuator"] = "pump"
    elif "buzzer" in text or "alarm" in text:
        intent["actuator"] = "buzzer"
    elif "relay" in text or "light" in text or "led" in text or "lamp" in text:
        intent["actuator"] = "led"

    # ACTION
    if any(word in text for word in ["turn on", "switch on", "start", "activate", "trigger"]):
        intent["action"] = "on"
    elif any(word in text for word in ["turn off", "switch off", "stop", "deactivate"]):
        intent["action"] = "off"

    # CONDITION
    if any(word in text for word in ["greater", "above", "exceed", "over", "higher"]):
        intent["operator"] = ">"
    elif any(word in text for word in ["less", "below", "under", "lower"]):
        intent["operator"] = "<"
    elif "dark" in text or "dim" in text or "cold" in text or "dry" in text:
        intent["operator"] = "<"
    elif "bright" in text or "hot" in text or "humid" in text or "wet" in text:
        intent["operator"] = ">"

    # NUMBER
    numbers = re.findall(r"\d+", text)
    if numbers:
        intent["threshold"] = int(numbers[0])

    return intent
