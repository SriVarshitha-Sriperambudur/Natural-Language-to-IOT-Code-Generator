def temperature_fan():
    code = """
#include "DHT.h"

#define DHTPIN 4
#define DHTTYPE DHT11
#define FAN_PIN 5

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  dht.begin();
  pinMode(FAN_PIN, OUTPUT);
}

void loop() {
  float temp = dht.readTemperature();
  Serial.println(temp);

  if (temp > 30) {
    digitalWrite(FAN_PIN, HIGH);
  } else {
    digitalWrite(FAN_PIN, LOW);
  }
  delay(2000);
}
"""
    wiring = """
DHT11 Sensor:
VCC  -> 3.3V
GND  -> GND
DATA -> GPIO 4

Relay Module (Fan):
IN   -> GPIO 5
VCC  -> 5V
GND  -> GND
"""
    return code, wiring


def soil_pump():
    code = """
#define SOIL_PIN 34
#define PUMP_PIN 5

void setup() {
  Serial.begin(9600);
  pinMode(PUMP_PIN, OUTPUT);
}

void loop() {
  int moisture = analogRead(SOIL_PIN);
  Serial.println(moisture);

  if (moisture < 2000) {
    digitalWrite(PUMP_PIN, HIGH);
  } else {
    digitalWrite(PUMP_PIN, LOW);
  }
  delay(2000);
}
"""
    wiring = """
Soil Moisture Sensor:
AO  -> GPIO 34
VCC -> 3.3V
GND -> GND

Relay Module (Pump):
IN  -> GPIO 5
"""
    return code, wiring
