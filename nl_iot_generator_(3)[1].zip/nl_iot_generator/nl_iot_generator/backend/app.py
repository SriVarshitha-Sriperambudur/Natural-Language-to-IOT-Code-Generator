from flask import Flask, request, jsonify, render_template
from ai_engine import process_command

app = Flask(
    __name__,
    template_folder="../frontend/templates",
    static_folder="../frontend/static"
)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(force=True)
    command = data.get("command", "")

    result = process_command(command)

    if result is None:
        return jsonify({"error": "Unable to process command"}), 400

    return jsonify({
        "prompt": command,
        **result
    })

if __name__ == "__main__":
    app.run(debug=True)

