async function generateCode() {
    const command = document.getElementById("command").value;

    if (command.trim() === "") {
        alert("Please enter a command");
        return;
    }

    const response = await fetch("/generate", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ command: command })
    });

    const data = await response.json();

    console.log(data); // 🔥 DEBUG LINE

    document.getElementById("output").classList.remove("hidden");

    document.getElementById("code").innerText = data.code;

    document.getElementById("wiring").innerText =
        JSON.stringify(data.wiring_instructions, null, 2);
}
